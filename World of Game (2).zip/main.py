from app import welcome, start_play

if __name__ == "__main__":
    user_name = input("Please enter your name: ")
    welcome(user_name)
    start_play()



